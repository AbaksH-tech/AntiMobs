package me.antimobs;

import org.bukkit.Bukkit;
import org.bukkit.Location;

public class Region {

    private final String world;
    private final double minX, minY, minZ;
    private final double maxX, maxY, maxZ;

    public Region(Location a, Location b) {
        this.world = a.getWorld().getName();

        minX = Math.min(a.getX(), b.getX());
        minY = Math.min(a.getY(), b.getY());
        minZ = Math.min(a.getZ(), b.getZ());

        maxX = Math.max(a.getX(), b.getX());
        maxY = Math.max(a.getY(), b.getY());
        maxZ = Math.max(a.getZ(), b.getZ());
    }

    public boolean contains(Location loc) {
        if (!loc.getWorld().getName().equals(world)) return false;

        return loc.getX() >= minX && loc.getX() <= maxX
                && loc.getY() >= minY && loc.getY() <= maxY
                && loc.getZ() >= minZ && loc.getZ() <= maxZ;
    }

    public String serialize() {
        return world + ";" +
                minX + ";" + minY + ";" + minZ + ";" +
                maxX + ";" + maxY + ";" + maxZ;
    }

    public static Region deserialize(String s) {
        String[] d = s.split(";");
        return new Region(
                new Location(Bukkit.getWorld(d[0]),
                        Double.parseDouble(d[1]),
                        Double.parseDouble(d[2]),
                        Double.parseDouble(d[3])),
                new Location(Bukkit.getWorld(d[0]),
                        Double.parseDouble(d[4]),
                        Double.parseDouble(d[5]),
                        Double.parseDouble(d[6]))
        );
    }
}
