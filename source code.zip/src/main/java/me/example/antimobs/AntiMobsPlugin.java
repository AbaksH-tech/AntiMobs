package me.antimobs;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AntiMobsPlugin extends JavaPlugin implements Listener {

    private final List<Region> regions = new ArrayList<>();
    private Location pos1, pos2;

    @Override
    public void onEnable() {
        loadRegions();
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        saveRegions();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;

        switch (cmd.getName()) {
            case "ampos1" -> {
                pos1 = p.getLocation();
                p.sendMessage("§aТочка 1 установлена");
            }
            case "ampos2" -> {
                pos2 = p.getLocation();
                p.sendMessage("§aТочка 2 установлена");
            }
            case "amsave" -> {
                if (pos1 == null || pos2 == null) {
                    p.sendMessage("§cСначала установи обе точки");
                    return true;
                }
                regions.add(new Region(pos1, pos2));
                p.sendMessage("§aРегион сохранён. Спавн мобов запрещён");
            }
        }
        return true;
    }

    @EventHandler
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) return;

        for (Region r : regions) {
            if (r.contains(e.getLocation())) {
                e.setCancelled(true);
                return;
            }
        }
    }

    // ❗ TNT взрывы
    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        Location loc = e.getLocation();

        for (Region r : regions) {
            if (r.contains(loc)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    // ❗ Криперы не взрываются
    @EventHandler
    public void onExplosionPrime(ExplosionPrimeEvent e) {
        if (!(e.getEntity() instanceof Creeper)) return;

        Location loc = e.getEntity().getLocation();

        for (Region r : regions) {
            if (r.contains(loc)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    private void saveRegions() {
        File f = new File(getDataFolder(), "regions.yml");
        YamlConfiguration cfg = new YamlConfiguration();

        int i = 0;
        for (Region r : regions) {
            cfg.set("regions." + i++, r.serialize());
        }

        try {
            cfg.save(f);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadRegions() {
        File f = new File(getDataFolder(), "regions.yml");
        if (!f.exists()) return;

        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        if (!cfg.contains("regions")) return;

        for (String key : cfg.getConfigurationSection("regions").getKeys(false)) {
            regions.add(Region.deserialize(cfg.getString("regions." + key)));
        }
    }
}
