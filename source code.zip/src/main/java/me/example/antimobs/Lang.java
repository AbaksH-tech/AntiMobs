package me.example.antimobs;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public class Lang {

    private final FileConfiguration config;

    public Lang(File file) {
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public String get(String path) {
        return config.getString(path, path).replace("&", "§");
    }

    public static void createDefaults(File langFolder) throws IOException {
        if (!langFolder.exists()) langFolder.mkdirs();

        createLang(langFolder, "ru_ru.yml",
                "pos1: \"&aПервая точка установлена\"",
                "pos2: \"&aВторая точка установлена\"",
                "need_pos: \"&cСначала установи обе точки!\"",
                "region_saved: \"&aРегион сохранён. Спавн мобов запрещён\""
        );

        createLang(langFolder, "en_en.yml",
                "pos1: \"&aFirst position set\"",
                "pos2: \"&aSecond position set\"",
                "need_pos: \"&cYou must set both positions first!\"",
                "region_saved: \"&aRegion saved. Mob spawning disabled\""
        );
    }

    private static void createLang(File folder, String name, String... lines) throws IOException {
        File file = new File(folder, name);
        if (file.exists()) return;

        file.createNewFile();
        YamlConfiguration cfg = new YamlConfiguration();
        for (String line : lines) {
            String[] split = line.split(": ", 2);
            cfg.set(split[0], split[1].replace("\"", ""));
        }
        cfg.save(file);
    }
}
